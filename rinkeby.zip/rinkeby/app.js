const express = require('express');
var Web3 = require ('web3');
const EthereumTx = require('ethereumjs-tx').Transaction;
var nodeBase64 = require('nodejs-base64-converter');


const bodyParser = require('body-parser');
var web3 = new Web3(new Web3.providers.HttpProvider('https://rinkeby.infura.io/v3/7c01a7bf81b34fd8ac7fbc6464a0b10d'));

var contractAddress =  "0x7C51d745c7F4ec4Cd00F058d7689Ef19087C153C";
var abi = [{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"approved","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_pdfName","type":"string"},{"internalType":"string","name":"_date","type":"string"},{"internalType":"string","name":"_image","type":"string"},{"internalType":"string","name":"_authorName","type":"string"}],"name":"create","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_pdfName","type":"string"},{"internalType":"string","name":"_image","type":"string"},{"internalType":"string","name":"_date","type":"string"},{"internalType":"string","name":"_authorName","type":"string"}],"name":"formatTokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"bytes","name":"_data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"tokenCounter","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"}];

const Contract = new web3.eth.Contract(abi, contractAddress);
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const port = 3000;

const key = '' // your account private key
const fromAddress = '' //Your account public Address


app.post('/api/create-pdf', async (req, res) => {

    try {
        var data = await Contract.methods.create(req.body.name, req.body.date, req.body.image,req.body.authorNAme);
        var privateKey = Buffer.from(key, 'hex');
        var encodeData = data.encodeABI();
        const txData = {
            nonce:  await web3.eth.getTransactionCount(fromAddress),
            gasPrice: web3.utils.toHex(42000000000),
            gasLimit: web3.utils.toHex(396058),
            to: contractAddress,
            from: fromAddress,
            value: 0x0,
            data: encodeData
        }

        const tx = new EthereumTx(txData,  {chain:'rinkeby'}); 
        tx.sign(privateKey);
        const serializedTx = tx.serialize()
        web3.eth.sendSignedTransaction('0x' + serializedTx.toString('hex'))
        .on('receipt', function(receipt){
            // res.status(200).send( receipt.transactionHash);
            web3.eth.getTransactionReceipt(receipt.transactionHash).then(function(receipt){
                let logs = receipt.logs;
                res.send({"Transaction Hash: ": receipt.transactionHash, "TokenID: ": web3.utils.hexToNumber(logs[0].topics[3])});
            });
        }).on('error', function(error){
            console.log("error", error)
            res.status(500).send(error)
        });
        
            
    } catch (error) {
        res.send(error)
    }
});

app.get('/api/getJson', async (req, res) => {
    try {
        var tokenURI = await Contract.methods.tokenURI(req.body.tokenID).call();
        var test = tokenURI.split('data:application/json;base64,')
        var json = nodeBase64.decode(test[1])
        res.send(json)
        
            
    } catch (error) {
        console.log('4', error)
        res.send(error)
    }
});
app.listen(process.env.PORT || port, () => { console.log("Api project is running now")})
